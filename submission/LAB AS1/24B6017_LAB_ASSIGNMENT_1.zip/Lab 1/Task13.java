public class Task13 {
  public static void main(String[] args) {
    int x,y;
    x =8; y=3;
    System.out.println(Math.PI*Math.max(4*y,Math.abs(x-y)));
  }
}

// Math PI gets the number for pi.
// Math max Check the largest among the number in the argument.
// Math abs returns the absolute values of the number.
